plugins {
    id("com.android.application")
}

android {
    namespace = "com.sade.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.sade.launcher"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = false
            // debug açarı ilə imzalanır ki, birbaşa telefona quraşdırmaq olsun
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}
